module.exports = app => {
  const razorpays = require("../controllers/razorpay.controller.js");

  var router = require("express").Router();

  router.post("/", razorpays.create);

  app.use("/api/razorpays", router);
};
