module.exports = app => {
  const adminrole = require("../controllers/adminrole.controller.js");
  const { authenticateToken } = require("./adminHelper");
  var router = require("express").Router();

  router.post("/", authenticateToken, adminrole.create);

  router.get("/", authenticateToken, adminrole.findAll);

  router.delete("/:id", authenticateToken, adminrole.delete);
  
  router.delete("/", authenticateToken, adminrole.deleteAll);

  router.put("/:id", authenticateToken, adminrole.update);

  router.get("/:id", authenticateToken, adminrole.findOne);

  app.use("/api/adminroles", router);
};
