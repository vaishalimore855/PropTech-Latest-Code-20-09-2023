module.exports = app => {
  const managers = require("../controllers/manager.controller.js");
  const { authenticateToken } = require("./adminHelper");
  var router = require("express").Router();

  router.post("/", authenticateToken, managers.create);

  router.get("/", authenticateToken, managers.findAll);

  router.delete("/:id", authenticateToken, managers.delete);
  
  router.delete("/", authenticateToken, managers.deleteAll);

  router.put("/:id", authenticateToken, managers.update);

  router.get("/:id", authenticateToken, managers.findOne);

  app.use("/api/managers", router);
};
