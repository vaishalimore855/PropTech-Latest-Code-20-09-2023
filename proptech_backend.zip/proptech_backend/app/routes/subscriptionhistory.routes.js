module.exports = app => {
  const subscriptionhostories = require("../controllers/subscriptionhistory.controller.js");
  const { authenticateToken } = require("./adminHelper");

  var router = require("express").Router();

  router.post("/", authenticateToken, subscriptionhostories.create);

  router.get("/", authenticateToken, subscriptionhostories.findAll);

  router.delete("/:id", authenticateToken, subscriptionhostories.delete);
  
  router.delete("/", authenticateToken, subscriptionhostories.deleteAll);

  router.put("/:id", authenticateToken, subscriptionhostories.update);

  router.get("/:id", authenticateToken, subscriptionhostories.findOne);

  app.use("/api/subscriptionshistory", router);
};
