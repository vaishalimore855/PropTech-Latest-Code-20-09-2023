require("dotenv").config();
const jwt = require("jsonwebtoken");
const { check, validationResult } = require("express-validator");

const secret = process.env.JWT_SECRET || "default";
const authenticateToken = (req, res, next) => {
  const token = req.headers.authorization;
  if (!token) {
    return res.status(401).json({ error: 'Missing access token' });
  }
   jwt.verify(token, secret, (err, decodedToken) => {
    if (err) {
      return res.status(403).json({ error: 'Invalid access token' });
    }
   req.user = decodedToken;
    next();
  });
};

module.exports = {
  authenticateToken
};
