module.exports = app => {
  const { upload } = require("../middlewares/multer")
  const users = require("../controllers/user.controller.js");
  

  var router = require("express").Router();

  router.post("/", users.create);

  router.get("/:userrole", users.findAll);

  router.delete("/:id", users.delete);
  
  router.delete("/", users.deleteAll);

  router.put("/:id", users.update);

  router.get("/userDetails/:id", users.findOne);

  const uploadMultiple = upload.fields([{ name: 'aadhar_front', maxCount: 1 },{ name: 'aadhar_back', maxCount: 1 }, { name: 'pan', maxCount: 1 }])
  
  //router.post('/upload-kyc', uploadMultiple, users.importKyc);

  router.post('/upload-kyc', users.importKyc);

  router.post('/update-kyc', users.updateKyc);

  router.delete('/delete-kyc/:id', users.deleteKyc);

  router.get("/get-kyc/:userid", users.getKyc);

  app.use("/api/users", router);
};
