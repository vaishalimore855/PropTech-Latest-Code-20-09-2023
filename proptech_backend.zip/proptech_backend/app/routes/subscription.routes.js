module.exports = app => {
  const subscriptions = require("../controllers/subscription.controller.js");
  const { authenticateToken } = require("./adminHelper");
  var router = require("express").Router();

  router.post("/", authenticateToken, subscriptions.create);

  router.get("/", authenticateToken, subscriptions.findAll);

  router.delete("/:id", authenticateToken, subscriptions.delete);
  
  router.delete("/", authenticateToken, subscriptions.deleteAll);

  router.put("/:id", authenticateToken, subscriptions.update);

  router.get("/:id", authenticateToken, subscriptions.findOne);

  app.use("/api/subscriptions", router);
};
