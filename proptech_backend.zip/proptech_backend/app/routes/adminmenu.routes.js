module.exports = app => {
  const adminmenus = require("../controllers/adminmenu.controller.js");
  const { authenticateToken } = require("./adminHelper");

  var router = require("express").Router();

  router.post("/", authenticateToken, adminmenus.create);

  router.get("/", authenticateToken, adminmenus.findAll);

  router.delete("/:id", authenticateToken, adminmenus.delete);
  
  router.delete("/", authenticateToken, adminmenus.deleteAll);

  router.put("/:id", authenticateToken, adminmenus.update);

  router.get("/:id", authenticateToken, adminmenus.findOne);

  app.use("/api/adminmenus", router);
};
