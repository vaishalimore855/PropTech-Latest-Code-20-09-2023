module.exports = app => {
  const { upload } = require("../middlewares/multer")
  const properties = require("../controllers/property.controller.js");
  const { authenticateToken } = require("./adminHelper");

  var router = require("express").Router();

  router.post("/", authenticateToken, upload.array("image"), properties.create);

  router.get("/", authenticateToken, properties.findAll);

  router.delete("/:id", authenticateToken, properties.delete);
  
  router.delete("/", authenticateToken, properties.deleteAll);

  router.put("/:id", authenticateToken, upload.array("image"), properties.update);

  router.get("/:id", authenticateToken, properties.findOne);

  router.get("/findByUser/:userid", authenticateToken, properties.findByUser);

  router.get("/findByAgent/:agentid", authenticateToken, properties.findByAgent);

  router.get("/getagent/:agentid", authenticateToken, properties.findAgentDetails);

  //router.post("/upload-array", upload.array("image"), properties.importArray);

  app.use("/api/property", router);
};
