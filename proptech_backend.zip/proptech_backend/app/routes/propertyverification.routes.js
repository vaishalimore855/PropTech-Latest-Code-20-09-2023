module.exports = app => {
  const { upload } = require("../middlewares/multer")
  const PropertyVerification = require("../controllers/propertyverification.controller.js");
  const { authenticateToken } = require("./adminHelper");

  var router = require("express").Router();

  router.post("/", authenticateToken, upload.array("image"), PropertyVerification.create);

  router.get("/", authenticateToken, PropertyVerification.findAll);

  router.delete("/:id", authenticateToken, PropertyVerification.delete);
  
  router.delete("/", authenticateToken, PropertyVerification.deleteAll);

  router.put("/:id", authenticateToken, upload.array("image"), PropertyVerification.update);

  router.put("/markasverify/:id", authenticateToken, PropertyVerification.MarkAsVerify);

  router.post("/markasunverify/:id", authenticateToken, PropertyVerification.UnMarkAsVerify);

  router.get("/:id", authenticateToken, PropertyVerification.findOne);

  app.use("/api/propertyverification", router);
};
