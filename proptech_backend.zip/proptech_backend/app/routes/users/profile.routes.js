module.exports = app => {
  const { upload } = require("../../middlewares/multer")
  const profiles = require("../../controllers/users/profile.controller.js");
  const { authenticateToken } = require("./usersHelper");

  var router = require("express").Router();

  //router.post("/", upload.single("photo"), authenticateToken, profiles.create);
  
  router.put("/:id", authenticateToken, profiles.update);

  router.get("/:id", authenticateToken, profiles.findOne);

  router.post("/changepassword", authenticateToken, profiles.changePassword);
  
  app.use("/api/profile", router);
};
