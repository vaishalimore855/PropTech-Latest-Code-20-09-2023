module.exports = app => {
  const auths = require("../../controllers/users/auth.controller.js");
  const { authenticateToken } = require("./usersHelper");

  var router = require("express").Router();

  router.post("/register", auths.register);

  router.post("/mobileverification", auths.Mobileverified);

  router.post("/login", auths.login);

  router.post("/forgotpass", auths.forgotpass);

  router.post("/resetpass", auths.resetpass);

  router.post("/changepassword", authenticateToken, auths.changePassword);
  
  router.put("/:id", authenticateToken, auths.update);

  router.get("/:id", authenticateToken, auths.findOne);

  app.use("/api/auths", router);
};
