module.exports = app => {
  const homes = require("../../controllers/users/home.controller.js");

  var router = require("express").Router();

  router.get("/:tagtype", homes.findAll);

  app.use("/api/homes", router);
};
