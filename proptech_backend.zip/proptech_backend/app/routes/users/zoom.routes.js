module.exports = app => {
  const { upload } = require("../../middlewares/multer")
  const zooms = require("../../controllers/users/zoom.controller.js");

  var router = require("express").Router();

  router.post("/createuser", zooms.createUser);
  
  app.use("/api/zoom", router);
  
};
