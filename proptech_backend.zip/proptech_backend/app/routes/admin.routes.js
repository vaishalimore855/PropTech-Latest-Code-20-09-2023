module.exports = app => {
  const admins = require("../controllers/admin.controller.js");
  const { authenticateToken } = require("./adminHelper");

  var router = require("express").Router();

  router.post("/login", admins.login);

  router.post("/changepassword", admins.changePassword);
  
  router.put("/:id", authenticateToken, admins.update);

  router.get("/:id", authenticateToken, admins.findOne);

  app.use("/api/admins", router);
};
