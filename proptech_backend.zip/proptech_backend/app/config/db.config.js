module.exports = {
  HOST: "localhost",
  USER: "postgres",
  PASSWORD: "Vaishali@123",
  DB: "proptech",
  dialect: "postgres",
  PORT:5433,
  pool: {
    max: 5,
    min: 0,
    acquire: 30000,
    idle: 10000
  }
};
