const db = require("../models");
const User = db.users;
const Op = db.Sequelize.Op;
const bcrypt = require('bcrypt');
const multer = require('multer');

const storage = multer.diskStorage({
  destination: function(req, file, cb) {
    cb(null, 'uploads/');
  },
  filename: function(req, file, cb) {
    const uniqueSuffix = Date.now() + '-' + Math.round(Math.random() * 1E9);
    cb(null, file.fieldname + '-' + uniqueSuffix);
  }
});

const upload = multer({ storage: storage });

exports.create = async(req, res) => {
  const password= req.body.password;
  const saltRounds = 10
  const salt = await bcrypt.genSalt(saltRounds);
  const userpassword = await bcrypt.hash(password, salt);

  if (!req.body.email || !req.body.password) {
    res.status(400).send({
      message: "email can not be empty!"
    });
    return;
  }

  // Create a Tutorial
  const user = {
    fullname: req.body.fullname,
    email: req.body.email,
    role: req.body.role,
    phoneNumber: req.body.phoneNumber,
    password: userpassword,
    isAdmin : true,
    menu: JSON.stringify(req.body.menu || [])
  };

  // Save Tutorial in the database
  User.create(user)
    .then(data => {
      res.send(data);
    })
    .catch(err => {
      res.status(500).send({
        message:
          err.message || "Some error occurred while creating the Manager."
      });
    });
};

exports.findAll = (req, res) => {
  const email = req.query.email;
  var condition = { isAdmin: true };

  User.findAll({ where: condition })
    .then(data => {
      res.send(data);
    })
    .catch(err => {
      res.status(500).send({
        message:
          err.message || "Some error occurred while retrieving users."
      });
    });
};

exports.AgentList = (req, res) => {
  const adminrole = req.params.adminrole;
  var condition = { isAdmin: true, role : adminrole };

  User.findAll({ where: condition })
    .then(data => {
      res.send(data);
    })
    .catch(err => {
      res.status(500).send({
        message:
          err.message || "Some error occurred while retrieving users."
      });
    });
};

exports.delete = (req, res) => {
  const id = req.params.id;

  User.destroy({
    where: { id: id }
  })
    .then(num => {
      if (num == 1) {
        res.send({
          message: "Manager was deleted successfully!"
        });
      } else {
        res.send({
          message: `Cannot delete Manager with id=${id}. Maybe Manager was not found!`
        });
      }
    })
    .catch(err => {
      res.status(500).send({
        message: "Could not delete Manager with id=" + id
      });
    });
};

exports.deleteAll = (req, res) => {
  User.destroy({
    where: {},
    truncate: false
  })
    .then(nums => {
      res.send({ message: `${nums} Manager were deleted successfully!` });
    })
    .catch(err => {
      res.status(500).send({
        message:
          err.message || "Some error occurred while removing all user."
      });
    });
};

exports.update = (req, res) => {
  const id = req.params.id;

    User.update(req.body, {
      where: { id: id }
    })
      .then(num => {
        if (num == 1) {
          res.send({
            message: "Manager was updated successfully."
          });
        } else {
          res.send({
            message: `Cannot update Manager with id=${id}. Maybe Manager was not found or req.body is empty!`
          });
        }
      })
      .catch(err => {
        res.status(500).send({
          message: "Error updating user with id=" + id
        });
      });
   };

// Find a single Tutorial with an id
exports.findOne = (req, res) => {
  const id = req.params.id;

  User.findByPk(id)
    .then(data => {
      res.send(data);
    })
    .catch(err => {
      res.status(500).send({
        message: "Error retrieving user with id=" + id
      });
    });
};




