const db = require("../models");
const Razorpay = require('razorpay');

exports.create = async(req, res) => {
 
  const razorpay = new Razorpay({
    key_id: 'rzp_test_GyojfUu6YjPAL6',
    key_secret: 'D2WPdmiPHPIINFGjHeYrSadc',
  });
  
  const options = {
    amount: 100, // Amount in paise (100 paise = 1 Rupee)
    currency: 'INR',
    receipt: 'order_receipt_1',
  };
  
  razorpay.orders.create(options, function (err, order) {
    if (err) {
      res.status(500).send({
        message:err
      });
    }

    res.send(order);
  });
  
};





