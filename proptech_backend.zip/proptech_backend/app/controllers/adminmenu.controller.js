const db = require("../models");
const AdminMenu = db.adminmenus;
const Op = db.Sequelize.Op;

exports.create = async(req, res) => {
  const { name, link, icon, parentid, priority, type } = req.body;
  const adminmenu = {
    name: req.body.name,
    link: req.body.link,
    icon: req.body.icon,
    parentid: req.body.parentid,
    priority: req.body.priority,
    type: req.body.type,
    status: true,
  };

  AdminMenu.create(adminmenu)
    .then(data => {
      res.send(data);
    })
    .catch(err => {
      res.status(500).send({
        message:
          err.message || "Some error occurred while creating the Admin Menu."
      });
    });
};


exports.findAll = (req, res) => {
  const status = req.query.status;
  const orderBy = [['priority', 'ASC']];

  AdminMenu.findAll({ order: orderBy })
    .then(data => {
      const mainMenu = [];
      const childMenu = [];

      data.forEach(item => {
        if (item.parentid) {
          
        } else {

          const subNav = data.filter(subItem => subItem.parentid == item.id).map(subItem => {
           return {
              title: subItem.name,
              path: subItem.link,
              icon: subItem.icon,
              priority: subItem.priority,
              parentid: subItem.parentid
            };
          });
          
          mainMenu.push({
            title: item.name,
            path: item.link,
            icon: item.icon,
            priority: item.priority,
            parentid: item.parentid,
            subNav: subNav
          });
        }
      });
      console.log(mainMenu);
      const sidebarData = mainMenu.map(item => ({
        title: item.title,
        path: item.path,
        icon: item.icon,
        priority: item.priority,
        parentid: item.parentid,
        subNav: item.subNav.map(subItem => ({
          title: subItem.title,
          path: subItem.path,
          icon: subItem.icon,
          priority: subItem.priority,
          parentid: subItem.parentid,
        }))
      }));
     res.status(200).send(sidebarData);
    })
    .catch(err => {
      res.status(500).send({
        message: err.message || "Some error occurred while retrieving Admin Menu."
      });
    });
};


exports.delete = (req, res) => {
  const id = req.params.id;

  AdminMenu.destroy({
    where: { id: id }
  })
    .then(num => {
      if (num == 1) {
        res.send({
          message: "Admin Menu was deleted successfully!"
        });
      } else {
        res.send({
          message: `Cannot delete Admin Menu with id=${id}. Maybe Admin Menu was not found!`
        });
      }
    })
    .catch(err => {
      res.status(500).send({
        message: "Could not delete Admin with id=" + id
      });
    });
};

exports.deleteAll = (req, res) => {
  AdminMenu.destroy({
    where: {},
    truncate: false
  })
    .then(nums => {
      res.send({ message: `${nums} Admin Menu were deleted successfully!` });
    })
    .catch(err => {
      res.status(500).send({
        message:
          err.message || "Some error occurred while removing all Admin Menu."
      });
    });
};

exports.update = (req, res) => {
  const id = req.params.id;

  AdminMenu.update(req.body, {
      where: { id: id }
    })
      .then(num => {
        if (num == 1) {
          res.send({
            message: "Admin Menu was updated successfully."
          });
        } else {
          res.send({
            message: `Cannot update Admin Menu with id=${id}. Maybe Admin Menu was not found or req.body is empty!`
          });
        }
      })
      .catch(err => {
        res.status(500).send({
          message: "Error updating user with id=" + id
        });
  });
};

// Find a single Tutorial with an id
exports.findOne = (req, res) => {
  const id = req.params.id;

  AdminMenu.findByPk(id)
    .then(data => {
      res.send(data);
    })
    .catch(err => {
      res.status(500).send({
        message: "Error retrieving Admin Menu with id=" + id
      });
    });
};




