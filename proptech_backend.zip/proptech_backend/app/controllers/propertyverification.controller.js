const db = require("../models");
const PropertyVerification = db.PropertyVerifications;
const Op = db.Sequelize.Op;

exports.create = async (req, res) => {
  const jsonData = {
    images: req.files.map(file => ({
      filename: file.filename
    }))
  };

  const imageData = {
    images: JSON.stringify(jsonData)
  };

  PropertyVerification.create(req.body)
    .then(async data => {
      await PropertyVerification.update(imageData, {
        where: { id: data.id }
      });
      res.send(data);
    })
    .catch(err => {
      res.status(500).send({
        message: err.message || "Some error occurred while creating the Property Verification."
      });
    });
};

exports.findAll = (req, res) => {
  PropertyVerification.findAll()
    .then(data => {
      res.send(data);
    })
    .catch(err => {
      res.status(500).send({
        message:
          err.message || "Some error occurred while retrieving Property Verification."
      });
    });
};

exports.delete = (req, res) => {
  const id = req.params.id;

  PropertyVerification.destroy({
    where: { id: id }
  })
    .then(num => {
      if (num == 1) {
        res.send({
          message: "Property Verification was deleted successfully!"
        });
      } else {
        res.send({
          message: `Cannot delete PropertyVerification with id=${id}. Maybe Property Verification was not found!`
        });
      }
    })
    .catch(err => {
      res.status(500).send({
        message: "Could not delete Property Verification with id=" + id
      });
    });
};

exports.deleteAll = (req, res) => {
  PropertyVerification.destroy({
    where: {},
    truncate: false
  })
    .then(nums => {
      res.send({ message: `${nums} Property Verification were deleted successfully!` });
    })
    .catch(err => {
      res.status(500).send({
        message:
          err.message || "Some error occurred while removing all Property Verification."
      });
    });
};

exports.update = async (req, res) => {
  const PropertyVerificationId = req.params.id;

  const jsonData = {
    images: req.files.map(file => ({
      fieldname: file.fieldname
    }))
  };

  const imageData = {
    images: jsonData
  };

  try {
    const PropertyVerification = await PropertyVerification.findByPk(PropertyVerificationId);
    if (!PropertyVerification) {
      return res.status(404).send({ message: 'Property Verification not found' });
    }

    await PropertyVerification.update(req.body, {
      where: { id: PropertyVerificationId }
    });

    await PropertyVerification.update(imageData, {
      where: { id: PropertyVerificationId }
    });

    const updatedPropertyVerification = await PropertyVerification.findByPk(PropertyVerificationId);

    res.send(updatedPropertyVerification);
  } catch (error) {
    res.status(500).send({
      message: 'Some error occurred while updating the Property Verification.',
      error: error.message
    });
  }
};

exports.findOne = (req, res) => {
  const id = req.params.id;

  PropertyVerification.findByPk(id)
    .then(async data => {
      res.send({
        PropertyVerificationdata: data
      });
    })
    .catch(err => {
      res.status(500).send({
        message: "Error retrieving Property Verification with id=" + id
      });
    });
};

exports.MarkAsVerify = (req, res) => {
  const id = req.params.id;

  const VerifyData = {
    verifystatus: true
  };

  PropertyVerification.update(VerifyData, {
    where: { id: id }
  })
    .then(num => {
      if (num == 1) {
        res.send({
          message: "Property Verification was successfully."
        });
      } else {
        res.send({
          message: `Cannot update Property Verification with id=${id}. Maybe Property Verification was not found or req.body is empty!`
        });
      }
    })
    .catch(err => {
      res.status(500).send({
        message: "Error updating Property Verification with id=" + id
      });
    });
};

exports.UnMarkAsVerify = (req, res) => {
  const id = req.params.id;

  const VerifyData = {
    reason: req.body.reason,
    verifystatus: false
  };

  PropertyVerification.update(VerifyData, {
    where: { id: id }
  })
    .then(num => {
      if (num == 1) {
        res.send({
          message: "Property Unverification was successfully."
        });
      } else {
        res.send({
          message: `Cannot update Property Unverification with id=${id}. Maybe Property Unverification was not found or req.body is empty!`
        });
      }
    })
    .catch(err => {
      res.status(500).send({
        message: "Error updating Property Unverification with id=" + id
      });
    });
};




