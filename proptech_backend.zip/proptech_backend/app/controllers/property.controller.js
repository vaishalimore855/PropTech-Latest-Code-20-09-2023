const db = require("../models");
const Property = db.properties;
const User = db.users;
const Op = db.Sequelize.Op;

exports.create = async (req, res) => {
  const jsonData = {
    images: req.files.map(file => ({
      filename: file.filename
    }))
  };

  const imageData = {
    images: JSON.stringify(jsonData)
  };

  Property.create(req.body)
    .then(async data => {
      await Property.update(imageData, {
        where: { id: data.id }
      });
      res.send(data);
    })
    .catch(err => {
      res.status(500).send({
        message: err.message || "Some error occurred while creating the Property."
      });
    });
};

exports.findAll = (req, res) => {
  Property.findAll()
    .then(data => {
      res.send(data);
    })
    .catch(err => {
      res.status(500).send({
        message:
          err.message || "Some error occurred while retrieving Property."
      });
    });
};

exports.delete = (req, res) => {
  const id = req.params.id;

  Property.destroy({
    where: { id: id }
  })
    .then(num => {
      if (num == 1) {
        res.send({
          message: "Property was deleted successfully!"
        });
      } else {
        res.send({
          message: `Cannot delete Property with id=${id}. Maybe Property was not found!`
        });
      }
    })
    .catch(err => {
      res.status(500).send({
        message: "Could not delete Property with id=" + id
      });
    });
};

exports.deleteAll = (req, res) => {
  Property.destroy({
    where: {},
    truncate: false
  })
    .then(nums => {
      res.send({ message: `${nums} Property were deleted successfully!` });
    })
    .catch(err => {
      res.status(500).send({
        message:
          err.message || "Some error occurred while removing all Property."
      });
    });
};

exports.update = async (req, res) => {
  const propertyId = req.params.id;

  const jsonData = {
    images: req.files.map(file => ({
      fieldname: file.fieldname
    }))
  };

  const imageData = {
    images: jsonData
  };

  try {
    const property = await Property.findByPk(propertyId);
    if (!property) {
      return res.status(404).send({ message: 'Property not found' });
    }

    await Property.update(req.body, {
      where: { id: propertyId }
    });

    await Property.update(imageData, {
      where: { id: propertyId }
    });

    const updatedProperty = await Property.findByPk(propertyId);

    res.send(updatedProperty);
  } catch (error) {
    res.status(500).send({
      message: 'Some error occurred while updating the Property.',
      error: error.message
    });
  }
};

exports.findOne = (req, res) => {
  const id = req.params.id;

  Property.findByPk(id)
    .then(async data => {
   res.send({
        propertydata: data
      });
    })
    .catch(err => {
      res.status(500).send({
        message: "Error retrieving Property with id=" + id
      });
    });
};

exports.findByUser = (req, res) => {
  const userid = req.params.userid;
  const condition = { userid: userid };

  Property.findAll({ where: condition })
    .then(data => {
      res.send(data);
    })
    .catch(err => {
      res.status(500).send({
        message:
          err.message || "Some error occurred while retrieving Property."
      });
    });
};

exports.findByAgent = (req, res) => {
  const agentid = req.params.agentid;
  const condition = { agentid: agentid };

  Property.findAll({ where: condition })
    .then(data => {
      res.send(data);
    })
    .catch(err => {
      res.status(500).send({
        message:
          err.message || "Some error occurred while retrieving Property."
      });
    });
};


exports.findAgentDetails = (req, res) => {
  const id = req.params.agentid;
  console.log(id);
  User.findByPk(id)
    .then(async data => {
    //const kycdata = await Kycs.findByPk(id);
      res.send({
        personaldata: data,
        //kaycdata: kycdata
      });
    })
    .catch(err => {
     // console.log(err);
      res.status(500).send({
        message: "Error retrieving user with id=" + id
      });
    });
};


