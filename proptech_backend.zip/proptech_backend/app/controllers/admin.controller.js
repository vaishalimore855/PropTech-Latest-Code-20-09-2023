const db = require("../models");
const User = db.users;
const Op = db.Sequelize.Op;
const bcrypt = require('bcrypt');
const { generateToken } = require("./usersHelper");

exports.login = async (req, res) => {
  const { email, password } = req.body;
  try {
    const condition = { email: email };

    User.findAll({ where: condition })
      .then(async data => {
        if (data.length === 0) {
          res.status(400).send({
            message: "Admin not found!"
          });
          return;
        }
        const user = data[0];
        const passwordMatch = await bcrypt.compare(password, user.password);

        if (passwordMatch) {
          res.status(200).send({
            message: "Admin Login Successfully",
            user: user,
            token: generateToken(user.email, user.id),
          });
        } else {
          res.status(400).send({
            message: "Incorrect password!"
          });
        }
      })
      .catch(err => {
        res.status(500).send({
          message: "Some error occurred while retrieving Admins.",
          error: err.message
        });
      });
  } catch (err) {
    res.status(500).send({
      message: "Error occurred during password encryption.",
      error: err.message
    });
  }
};

exports.changePassword = async (req, res) => {
  const { email, currentPassword, newPassword } = req.body;

  try {
    // Retrieve user data from the database
    const user = await User.findOne({ email });
    
    if (!user) {
      res.status(404).send({ message: 'Admin not found' });
      return;
    }
   
    const passwordMatch = await bcrypt.compare(currentPassword, user.password);
    if (!passwordMatch) {
      res.status(400).send({ message: 'Incorrect current password' });
      return;
    }

    // Generate a new bcrypt hash for the new password
    const newHashedPassword = await bcrypt.hash(newPassword, 10);
    // Update the user's password in the database
    user.password = newHashedPassword;
    await user.save();

    res.status(200).send({ message: 'Password changed successfully' });
  } catch (error) {
    res.status(500).send({ message: 'Error occurred during password change', error: error.message });
  }
};

exports.update = (req, res) => {
  const id = req.params.id;

    User.update(req.body, {
      where: { id: id }
    })
      .then(num => {
        if (num == 1) {
          res.send({
            message: "Admin was updated successfully."
          });
        } else {
          res.send({
            message: `Cannot update Admin with id=${id}. Maybe Admin was not found or req.body is empty!`
          });
        }
      })
      .catch(err => {
        res.status(500).send({
          message: "Error updating user with id=" + id
        });
      });
};

exports.findOne = (req, res) => {
  const id = req.params.id;

  User.findByPk(id)
    .then(data => {
      res.send(data);
    })
    .catch(err => {
      res.status(500).send({
        message: "Error retrieving user with id=" + id
      });
    });
};




