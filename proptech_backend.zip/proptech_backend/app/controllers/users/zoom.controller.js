const db = require("../../models");
require('dotenv').config();
var thenrequest = require('then-request');
const zoomAPIKey = process.env.ZOOM_CLIENT_ID;
const zoomAPISecret = process.env.ZOOM_CLIENT_SECRET;
const zoomAPIBaseUrl = 'https://api.zoom.us/v2/';

exports.createUser = async (req, res) => {
  const options = {
    qs: {
      api_key: zoom_key,
      api_secret: zoom_sec,
      data_type: "JSON",
      email: req.body.email,
      type: 2
    }
  };

  try {
    // make an asynchronous request to zoom to create a User
    const asyncres = await thenrequest('POST', "https://dev.zoom.us/v1/user/create", options);
    console.log(asyncres.getBody('utf8'));
    res.redirect('/');
  } catch (error) {
    console.error(error);
    res.status(500).send({
      message: "Some error occurred while creating the user."
    });
  }
};



