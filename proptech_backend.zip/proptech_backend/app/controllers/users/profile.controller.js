const db = require("../../models");
const UserProfile = db.userprofiles;
const User = db.users;
const bcrypt = require('bcrypt');
const crypto = require('crypto');
const nodemailer = require('nodemailer');
const path = require('path');
const fs = require('fs');


function getImageFilePath(imageName) {
  const targetFolder = './images'; 
  return path.join(__dirname, '..', '..', '..', targetFolder, imageName);
}

function generateTargetPath(folder, extension) {
  const currentDatetime = new Date().toISOString().replace(/:/g, '-');
  const filename = `image_${currentDatetime}.${extension}`;
  return `${folder}/${filename}`;
}

function saveBase64Image(base64Data, folder) {
  const base64ImageRegex = /^data:image\/(png|jpeg|jpg);base64,/;
  if (!base64ImageRegex.test(base64Data)) {
    throw new Error('Invalid base64 image data.');
  }

  const base64Image = base64Data.replace(base64ImageRegex, '');
  const extension = base64Data.split('/')[1].split(';')[0]; // Extract image extension from base64 data
  const targetPath = generateTargetPath(folder, extension);
  fs.writeFileSync(targetPath, base64Image, { encoding: 'base64' });
  return targetPath;
}


exports.update = async (req, res) => {
  const id = req.params.id;
  const targetFolder = './images';
  const savedImagePath = await saveBase64Image(req.body.image,targetFolder);

  const userData = {
    fullname:req.body.fullname,
    email:req.body.email,
    phoneNumber: req.body.phoneNumber,
    isAdmin : false,
    image: savedImagePath,
    city : req.body.city,
    address : req.body.address,
  };

  User.update(userData, {
      where: { id: id }
    })
      .then(num => {
        if (num == 1) {
          res.send({
            message: "Users was updated successfully."
          });
        } else {
          res.send({
            message: `Cannot update Users with id=${id}. Maybe Users was not found or req.body is empty!`
          });
        }
      })
      .catch(err => {
        res.status(500).send({
          message: "Error updating user with id=" + id
        });
      });
};

exports.changePassword = async (req, res) => {
  const { id, currentPassword, newPassword } = req.body;
  try {
    // Retrieve user data from the database
    const user = await User.findOne({ id });
    if (!user) {
      res.status(404).send({ message: 'User not found' });
      return;
    }
   const passwordMatch = await bcrypt.compare(currentPassword, user.password);
    if (!passwordMatch) {
      res.status(400).send({ message: 'Incorrect current password' });
      return;
    }

    // Generate a new bcrypt hash for the new password
    const newHashedPassword = await bcrypt.hash(newPassword, 10);
    // Update the user's password in the database
    user.password = newHashedPassword;
    await user.save();

    res.status(200).send({ status:true ,message: 'Password changed successfully' });
  } catch (error) {
    res.status(500).send({ status:false ,message: 'Error occurred during password change', error: error.message });
  }
};

exports.findOne = (req, res) => {
  const id = req.params.id;
    User.findByPk(id)
    .then(data => {
      const str= data.image;
      const parts = str.split('/');
      const imagePath = getImageFilePath(parts[2]);
      const base64Image = imagePath.toString('base64');
      fs.readFile(imagePath, (err, imageData) => {
        if (err) {
          return res.status(404).send('Image not found');
        }
        const base64Image = imageData.toString('base64');
        res.status(200).send({
          status:true,
          Userdata:data,
          ProfileImage:base64Image
        });
      });
    })
    .catch(err => {
      res.status(500).send({
        message: "Error retrieving user with id=" + err
      });
    });
};




