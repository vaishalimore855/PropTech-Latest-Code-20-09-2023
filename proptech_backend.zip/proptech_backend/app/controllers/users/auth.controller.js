const db = require("../../models");
const User = db.users;
const Mobileverify = db.mobileverify;
const ResetTokens = db.resettokens;
const Op = db.Sequelize.Op;
const jwt = require('jsonwebtoken');
const bcrypt = require('bcrypt');
const crypto = require('crypto');
const axios = require('axios');
const { generateToken } = require("../usersHelper");
const nodemailer = require('nodemailer');

const transporter = nodemailer.createTransport({
  service: 'Gmail', // Replace with the email service you want to use, or provide your SMTP configuration
  auth: {
    user: 'santosh.cisconic@gmail.com', // Replace with your email address
    pass: 'Anshu1940@', // Replace with your email password or an app-specific password
   
  },
});

const apiKey = 'MzM2YjQ4NDM0NjZmNTc3NTQ5NTY0MjYzNjc3MzZlNmY='; // Replace this with your Textlocal API key
const sender = 'PROPTH'; // Replace this with your desired sender name

const generateOTP = () => {
  return Math.floor(100000 + Math.random() * 900000).toString();
};

exports.Mobileverified = async(req, res) => {
  
  const phoneNumber = req.body.phoneNumber;

  const condition = { phoneNumber: phoneNumber };
  const Mobile = await Mobileverify.findOne({ where: condition });
  const otp = await generateOTP();
  
  const userMobile = {
    phoneNumber,
    MobileOTP:otp,
  };
  
  if(Mobile){
    User.update(userMobile, {
      where: { id: Mobile.id }
    })
      .then(async num => {
        if (num == 1) {
          await sendOTP(otp, phoneNumber);
          res.send({
            phoneNumber: phoneNumber,
            otp: otp
          });
        } else {
          res.send({
            message: `Cannot update user mobile with id=${id}. Maybe User was not found or req.body is empty!`
          });
        }
      })
      .catch(err => {
        res.status(500).send({
          message: "Error updating user with id=" + id
        });
      });

  }else{
    
    Mobileverify.create(userMobile)
    .then(async data => {
      await sendOTP(otp, phoneNumber);
      res.send(data);
    })
    .catch(err => {
      res.status(500).send({
        message:
          err.message || "Some error occurred while creating the Users."
      });
    });

  }
 
};

exports.register = async(req, res) => {
  const password= req.body.password;
  const saltRounds = 10
  const salt = await bcrypt.genSalt(saltRounds);
  const userpassword = await bcrypt.hash(password, salt);
  const fullname = req.body.fullname;
  const email = req.body.email;
  const phoneNumber = req.body.phoneNumber;
  if (!req.body.email || !req.body.password) {
    res.status(400).send({
      message: "email can not be empty!"
    });
    return;
  }

  const condition = { email: email };
  const userData = await User.findOne({ where: condition });
  if (userData) {
      return res.status(400).send({
        message: "Email is already registered."
      });
    }

  const phonecondition = { phoneNumber : phoneNumber };
  const userPhData = await User.findOne({ where: phonecondition });
  if (userPhData) {
      return res.status(400).send({
        message: "Phone Number is already registered."
      });
    }

  const user = {
    fullname,
    email,
    userrole : req.body.userrole,
    phoneNumber: phoneNumber,
    password: userpassword,
    Mobileverified:req.body.mobileverified,
    isAdmin : false,
  };

  User.create(user)
    .then(async data => {
      const from ="trupti.cyperts@gmail.com";
      const to = email;
      const subject ="Welcome to PropTech!";
      const text ="Hello ${fullname},\n\nThank you for registering on PropTech. We're excited to have you on board!";
      await SendEmail(from,to,subject,text);
      res.status(200).send({
        status:true,
        data:data
      });

      res.send(data);
    })
    .catch(err => {
      res.status(500).send({
        status:false,
        message:
          err.message || "Some error occurred while creating the Users."
      });
    });
};

exports.login = async (req, res) => {
  const { email, password } = req.body;
  try {
    const condition = { email: email };

    User.findAll({ where: condition })
      .then(async data => {
        if (data.length === 0) {
          res.status(400).send({
            message: "User not found!"
          });
          return;
        }

        const user = data[0];
        const passwordMatch = await bcrypt.compare(password, user.password);
       if (passwordMatch) {
          res.status(200).send({
            status:true,
            message: "User Login Successfully",
            user: user,
            token: generateToken(user.email, user.id),
          });
        } else {
          res.status(400).send({
            status:false,
            message: "Incorrect password!"
          });
        }
      })
      .catch(err => {
        res.status(500).send({
          status:false,
          message: "Some error occurred while retrieving user.",
          error: err.message
        });
      });
  } catch (err) {
    res.status(500).send({
      status:false,
      message: "Error occurred during password encryption.",
      error: err.message
    });
  }
};

exports.forgotpass = async (req, res) => {
  const { email } = req.body;
  try {
    const condition = { email: email };
    const user = await User.findOne({ where: condition });

    if (!user) {
      return res.status(404).send({
        status:false,
        message: "User not found with the provided email."
      });
    }
    
    const resettoken = await ResetTokens.findOne({ where: condition });
    const getResetToken = await generateResetToken();
    const resetpassData = {
      email:user.email,
      userid:user.id,
      token: getResetToken,
    };

    if (!resettoken) {
      ResetTokens.create(resetpassData);
    }else{
      ResetTokens.update(resetpassData, {
        where: { id: resettoken.id }
    })
   }
  
    const from = "trupti.cyperts@gmail.com";
    const to = email;
    const subject = "Password Reset for PropTech";
    const text = `Hello ${user.fullname},\n\nWe received a request to reset your password. If you didn't initiate this request, you can ignore this email. Otherwise, click on the following link to reset your password: https://example.com/reset-password?token=${getResetToken}\n\nThank you,\nPropTech Team`;

    await SendEmail(from,to,subject,text);

    res.send({
      message: "Email sent to your provided email. Please check your inbox!"
    });
  } catch (err) {
    res.status(500).send({
      status:false,
      message: "Error occurred while sending the email.",
      error: err.message
    });
  }
};

exports.resetpass = async (req, res) => {
  const { email,token,password,confpassword } = req.body;
  try {
    const condition = { email: email };
    const user = await User.findOne({ where: condition });

    if (password != confpassword) {
      return res.status(404).send({
        status:false, 
        message: "Password and Confirm password does not match"
      });
    }

    if (!user) {
      return res.status(404).send({
        status:false,
        message: "User not found with the provided email."
      });
    }

    const resettoken = await ResetTokens.findOne({ where: condition });
    if (!resettoken) {
      return res.status(404).send({
        status:false,
        message: "Reset Token not found with the provided email."
      });
    }

    if(token!=resettoken.token){
      return res.status(404).send({
        status:false,
        message: "Reset Token is invalid with the provided email."
      });
    }
  
     const newHashedPassword = await bcrypt.hash(password, 10);
     
     console.log("newHashedPassword",newHashedPassword);
     user.password = newHashedPassword;
     await user.save();
 
     res.status(200).send({ status:true, message: 'Password has been successfully reset. You can now log in with your new password.' });

  } catch (err) {
    res.status(500).send({
      status:false,
      message: "Error occurred while sending the email.",
      error: err.message
    });
  }
};

function generateResetToken() {
  return new Promise((resolve, reject) => {
    crypto.randomBytes(32, (err, buffer) => {
      if (err) {
        reject(err);
      } else {
        const resetToken = buffer.toString('hex');
        resolve(resetToken);
      }
    });
  });
}

exports.changePassword = async (req, res) => {
  const { email, currentPassword, newPassword } = req.body;
  try {
    // Retrieve user data from the database
    const user = await User.findOne({ email });
    if (!user) {
      res.status(404).send({ message: 'User not found' });
      return;
    }
   const passwordMatch = await bcrypt.compare(currentPassword, user.password);
    if (!passwordMatch) {
      res.status(400).send({ message: 'Incorrect current password' });
      return;
    }

    // Generate a new bcrypt hash for the new password
    const newHashedPassword = await bcrypt.hash(newPassword, 10);
    // Update the user's password in the database
    user.password = newHashedPassword;
    await user.save();

    res.status(200).send({ message: 'Password changed successfully' });
  } catch (error) {
    res.status(500).send({ message: 'Error occurred during password change', error: error.message });
  }
};

exports.update = (req, res) => {
  const id = req.params.id;

    User.update(req.body, {
      where: { id: id }
    })
      .then(num => {
        if (num == 1) {
          res.send({
            status:true,
            message: "User was updated successfully."
          });
        } else {
          res.send({
            status:false,
            message: `Cannot update User with id=${id}. Maybe User was not found or req.body is empty!`
          });
        }
      })
      .catch(err => {
        res.status(500).send({
          status:false,
          message: "Error updating user with id=" + id
        });
      });
};

exports.findOne = (req, res) => {
  const id = req.params.id;
  console.log(id);
  User.findByPk(id)
    .then(data => {
      console.log(data);
      res.status(200).send({
        status:true,
        data:data
      });
     
    })
    .catch(err => {
      res.status(500).send({
        status:false,
        message: "Error retrieving user with id=" + id
      });
    });
};

async function SendEmail(from,to,subject,text){
  const mailOptions = {
    from,
    to,
    subject,
    text
  };
  
  transporter.sendMail(mailOptions, (error, info) => {
    if (error) {
      console.log('Error occurred:', error.message);
    } else {
      console.log('Email sent:', info.response);
    }
  });
};

const sendOTP = async (otp, phoneNumber) => {
  const message = `Your OTP is: ${otp}`;

  try {
    const response = await axios.post('https://api.textlocal.in/send', {
      apiKey: apiKey,
      numbers: phoneNumber,
      //sender: sender,
      message: message,
    });

    console.log('OTP sent successfully:', response.data);
  } catch (error) {
    console.error('Error sending OTP:', error.message);
  }
};


