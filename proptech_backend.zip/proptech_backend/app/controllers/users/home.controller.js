const db = require("../../models");
const Property = db.properties;
const Op = db.Sequelize.Op;
const fs = require("fs");

exports.findAll = (req, res) => {
  const propertytype = req.params.tagtype;
  var condition = { listedIn: { [Op.iLike]: propertytype } };

  Property.findAll({ where: condition })
    .then(data => {
      res.send(data);
    })
    .catch(err => {
      res.status(500).send({
        message:
          err.message || "Some error occurred while retrieving Property."
      });
    });
};





