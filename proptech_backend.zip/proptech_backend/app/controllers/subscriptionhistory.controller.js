const db = require("../models");
const Subscriptionhistories = db.subscriptionhistory;
const multer = require('multer');

const storage = multer.diskStorage({
  destination: function(req, file, cb) {
    cb(null, 'uploads/');
  },
  filename: function(req, file, cb) {
    const uniqueSuffix = Date.now() + '-' + Math.round(Math.random() * 1E9);
    cb(null, file.fieldname + '-' + uniqueSuffix);
  }
});

const upload = multer({ storage: storage });

exports.create = async(req, res) => {
 
  const subscription = {
    subscriptionid: req.body.subscriptionid,
    txid: req.body.txid,
    paymentmethod: "Razorpay",
    paymentamount: req.body.paymentamount,
    currency: req.body.currency,
    status: req.body.status,
  };

  Subscriptionhistories.create(subscription)
    .then(data => {
      res.send(data);
    })
    .catch(err => {
      res.status(500).send({
        message:
          err.message || "Some error occurred while creating the Subscription."
      });
    });
};

exports.findAll = (req, res) => {
  Subscriptionhistories.findAll()
    .then(data => {
      res.send(data);
    })
    .catch(err => {
      res.status(500).send({
        message:
          err.message || "Some error occurred while retrieving Subscription."
      });
    });
};

exports.delete = (req, res) => {
  const id = req.params.id;

  Subscriptionhistories.destroy({
    where: { id: id }
  })
    .then(num => {
      if (num == 1) {
        res.send({
          message: "Subscription was deleted successfully!"
        });
      } else {
        res.send({
          message: `Cannot delete Subscription with id=${id}. Maybe Subscription was not found!`
        });
      }
    })
    .catch(err => {
      res.status(500).send({
        message: "Could not delete Subscription with id=" + id
      });
    });
};

exports.deleteAll = (req, res) => {
  Subscriptionhistories.destroy({
    where: {},
    truncate: false
  })
    .then(nums => {
      res.send({ message: `${nums} Subscription were deleted successfully!` });
    })
    .catch(err => {
      res.status(500).send({
        message:
          err.message || "Some error occurred while removing all Subscription."
      });
    });
};

exports.update = (req, res) => {
  const id = req.params.id;

  Subscriptionhistories.update(req.body, {
      where: { id: id }
    })
      .then(num => {
        if (num == 1) {
          res.send({
            message: "Subscription was updated successfully."
          });
        } else {
          res.send({
            message: `Cannot update Subscription with id=${id}. Maybe Subscription was not found or req.body is empty!`
          });
        }
      })
      .catch(err => {
        res.status(500).send({
          message: "Error updating user with id=" + id
        });
      });
   };

exports.findOne = (req, res) => {
  const id = req.params.id;

  Subscriptionhistories.findByPk(id)
    .then(data => {
      res.send(data);
    })
    .catch(err => {
      res.status(500).send({
        message: "Error retrieving Subscription with id=" + id
      });
    });
};




