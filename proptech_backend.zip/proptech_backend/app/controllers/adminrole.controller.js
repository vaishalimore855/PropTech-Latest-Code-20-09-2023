const db = require("../models");
const AdminRole = db.adminroles;
const Op = db.Sequelize.Op;

exports.create = async(req, res) => {
  const adminrole = {
    role: req.body.role,
    status: true
  };

  AdminRole.create(adminrole)
    .then(data => {
      res.send(data);
    })
    .catch(err => {
      res.status(500).send({
        message:
          err.message || "Some error occurred while creating the Admin Role."
      });
    });
};

exports.findAll = (req, res) => {
  const status = req.query.status;
  var condition = status ? { status: { [Op.iLike]: `%${status}%` } } : null;

  AdminRole.findAll({ where: condition })
    .then(data => {
      res.send(data);
    })
    .catch(err => {
      res.status(500).send({
        message:
          err.message || "Some error occurred while retrieving Admin Role."
      });
    });
};

exports.delete = (req, res) => {
  const id = req.params.id;

  AdminRole.destroy({
    where: { id: id }
  })
    .then(num => {
      if (num == 1) {
        res.send({
          message: "Admin Role was deleted successfully!"
        });
      } else {
        res.send({
          message: `Cannot delete Admin Role with id=${id}. Maybe Admin Role was not found!`
        });
      }
    })
    .catch(err => {
      res.status(500).send({
        message: "Could not delete Admin with id=" + id
      });
    });
};

exports.deleteAll = (req, res) => {
  AdminRole.destroy({
    where: {},
    truncate: false
  })
    .then(nums => {
      res.send({ message: `${nums} Admin Role were deleted successfully!` });
    })
    .catch(err => {
      res.status(500).send({
        message:
          err.message || "Some error occurred while removing all Admin Role."
      });
    });
};

exports.update = (req, res) => {
  const id = req.params.id;

  AdminRole.update(req.body, {
      where: { id: id }
    })
      .then(num => {
        if (num == 1) {
          res.send({
            message: "Admin Role was updated successfully."
          });
        } else {
          res.send({
            message: `Cannot update Admin Role with id=${id}. Maybe Admin Role was not found or req.body is empty!`
          });
        }
      })
      .catch(err => {
        res.status(500).send({
          message: "Error updating user with id=" + id
        });
  });
};

// Find a single Tutorial with an id
exports.findOne = (req, res) => {
  const id = req.params.id;

  AdminRole.findByPk(id)
    .then(data => {
      res.send(data);
    })
    .catch(err => {
      res.status(500).send({
        message: "Error retrieving admin role with id=" + id
      });
    });
};




