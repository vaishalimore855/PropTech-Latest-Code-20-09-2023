const db = require("../models");
const User = db.users;
const Kycs = db.kycs;
const Op = db.Sequelize.Op;
const bcrypt = require('bcrypt');
const path = require('path');
const fs = require("fs");

function getImageFilePath(imageName) {
  const targetFolder = './images/kycdata'; 
  return path.join(__dirname, '..', '..', targetFolder, imageName);
}

function generateTargetPath(folder, extension) {
  const currentDatetime = new Date().toISOString().replace(/:/g, '-');
  const filename = `image_${currentDatetime}.${extension}`;
  return `${folder}/${filename}`;
}

function saveBase64Image(base64Data, folder) {
  const base64ImageRegex = /^data:image\/(png|jpeg|jpg);base64,/;
  if (!base64ImageRegex.test(base64Data)) {
    throw new Error('Invalid base64 image data.');
  }

  const base64Image = base64Data.replace(base64ImageRegex, '');
  const extension = base64Data.split('/')[1].split(';')[0]; // Extract image extension from base64 data
  const targetPath = generateTargetPath(folder, extension);
  fs.writeFileSync(targetPath, base64Image, { encoding: 'base64' });
  return targetPath;
}

exports.create = async(req, res) => {
  const password= req.body.password;
  const saltRounds = 10;
  const email = req.body.email;
  const phoneNumber = req.body.phoneNumber;
  const salt = await bcrypt.genSalt(saltRounds);
  const userpassword = await bcrypt.hash(password, salt);

  if (!req.body.email || !req.body.password) {
    res.status(400).send({
      message: "email can not be empty!"
    });
    return;
  }

  const condition = { email: email };
  const userData = await User.findOne({ where: condition });
  if (userData) {
      return res.status(400).send({
        message: "Email is already registered."
      });
    }

  const phonecondition = { phoneNumber : phoneNumber };
  const userPhData = await User.findOne({ where: phonecondition });
  if (userPhData) {
      return res.status(400).send({
        message: "Phone Number is already registered."
      });
    }

  const user = {
    fullname: req.body.fullname,
    email,
    phoneNumber,
    userrole : req.body.userrole,
    password: userpassword,
    isAdmin : false
  };

  User.create(user)
    .then(data => {
      res.send(data);
    })
    .catch(err => {
      res.status(500).send({
        message:
          err.message || "Some error occurred while creating the Users."
      });
    });
};

exports.findAll = (req, res) => {
  const userrole = req.params.userrole;
  var condition = { isAdmin: false , userrole:userrole };

  User.findAll({ where: condition })
    .then(data => {
      res.send(data);
    })
    .catch(err => {
      res.status(500).send({
        message:
          err.message || "Some error occurred while retrieving users."
      });
    });
};

exports.delete = (req, res) => {
  const id = req.params.id;

  User.destroy({
    where: { id: id }
  })
    .then(num => {
      if (num == 1) {
        res.send({
          message: "Users was deleted successfully!"
        });
      } else {
        res.send({
          message: `Cannot delete Users with id=${id}. Maybe Users was not found!`
        });
      }
    })
    .catch(err => {
      res.status(500).send({
        message: "Could not delete Users with id=" + id
      });
    });
};

exports.deleteAll = (req, res) => {
  User.destroy({
    where: {},
    truncate: false
  })
    .then(nums => {
      res.send({ message: `${nums} Users were deleted successfully!` });
    })
    .catch(err => {
      res.status(500).send({
        message:
          err.message || "Some error occurred while removing all user."
      });
    });
};

exports.update = (req, res) => {
  const id = req.params.id;

    User.update(req.body, {
      where: { id: id }
    })
      .then(num => {
        if (num == 1) {
          res.send({
            message: "Users was updated successfully."
          });
        } else {
          res.send({
            message: `Cannot update Users with id=${id}. Maybe Users was not found or req.body is empty!`
          });
        }
      })
      .catch(err => {
        res.status(500).send({
          message: "Error updating user with id=" + id
        });
      });
   };

// Find a single Tutorial with an id
exports.findOne = (req, res) => {
  const id = req.params.id;
  User.findByPk(id)
    .then(async data => {
     res.send({
        personaldata: data
      });
    })
    .catch(err => {
      res.status(500).send({
        message: "Error retrieving user with id=" + id
      });
    });
};

exports.importKyc = async (req, res) => {
  const id = req.params.id;
  const targetFolder = './images/kycdata';
  console.log("req.body.aadhar_front",req.body.aadhar_front);
  const aadharfrontImagePath = await saveBase64Image(req.body.aadhar_front , targetFolder);
  const aadharbackImagePath = await saveBase64Image(req.body.aadhar_back , targetFolder);
  const panImagePath = await saveBase64Image(req.body.pan , targetFolder);

   const kyc = {
    aadhar_front: aadharfrontImagePath,
    aadhar_back: aadharbackImagePath,
    pan: panImagePath,
    userid: req.body.userid,
  };

    Kycs.create(kyc)
    .then(data => {
      res.send({status:true, data:data });
    })
    .catch(err => {
      res.status(500).send({
        status:false,
        message:
          err.message || "Some error occurred while creating the User Kyc."
      });
    });
   };


 const deleteFile = (filename) => {
    return new Promise((resolve, reject) => {
      const filePath = `images/${filename}`;
      if (!fs.existsSync(filePath)) {
        return resolve();
      }
  
      fs.unlink(filePath, (err) => {
        if (err) {
          reject(err);
        } else {
          resolve();
        }
      });
    });
  };

exports.updateKyc = async (req, res) => {
  const id = req.body.id;
  
  const targetFolder = './images/kycdata';
  const aadharfrontImagePath = await saveBase64Image(req.body.aadhar_front , targetFolder);
  const aadharbackImagePath = await saveBase64Image(req.body.aadhar_back , targetFolder);
  const panImagePath = await saveBase64Image(req.body.pan , targetFolder);

   const kyc = {
    aadhar_front: aadharfrontImagePath?aadharfrontImagePath:null,
    aadhar_back: aadharbackImagePath?aadharbackImagePath:null,
    pan: panImagePath?panImagePath:null,
    userid: req.body.userid,
  };

  
    Kycs.findByPk(id)
      .then(kycData => {
        if (!kycData) {
          return res.status(404).send({
            status:false,
            message: "Kyc not found with id " + id
          });
        }
  
        const deletionPromises = [];
  
        if (req.files.aadhar_front) {
          deletionPromises.push(deleteFile(kycData.aadhar_front));
        }
  
        if (req.files.aadhar_back) {
          deletionPromises.push(deleteFile(kycData.aadhar_back));
        }
  
        if (req.files.pan) {
          deletionPromises.push(deleteFile(kycData.pan));
        }
  
        Promise.all(deletionPromises)
          .then(() => {
            // Update Kyc with the new image filenames
            kycData.update(kyc)
              .then(data => {
                res.send({status:true, data:data});
              })
              .catch(err => {
                res.status(500).send({
                  message: err.message || "Some error occurred while updating the Kyc."
                });
              });
          })
          .catch(err => {
            res.status(500).send({
              message: err.message || "Some error occurred while deleting files."
            });
          });
      })
      .catch(err => {
        res.status(500).send({
          message: err.message || "Some error occurred while retrieving the Kyc."
        });
      });
  };

exports.deleteKyc = (req, res) => {
    const id = req.params.id;
    
    Kycs.findByPk(id)
      .then(kycData => {
        if (!kycData) {
          return res.status(404).send({
            message: "Kyc not found with id " + id
          });
        }
  
        const deletionPromises = [];
  
          deletionPromises.push(deleteFile(kycData.aadhar_front));
          deletionPromises.push(deleteFile(kycData.aadhar_back));
          deletionPromises.push(deleteFile(kycData.pan));
      
        Promise.all(deletionPromises)
          .then(() => {
            Kycs.destroy({
              where: { id: id }
            })
              .then(num => {
                if (num == 1) {
                  res.send({
                    message: "User Kyc was deleted successfully!"
                  });
                } else {
                  res.send({
                    message: `Cannot delete User Kyc with id=${id}. Maybe User Kyc was not found!`
                  });
                }
              })
          })
          .catch(err => {
            res.status(500).send({
              message: "Could not delete User Kyc with id=" + id
            });
          })
          .catch(err => {
            res.status(500).send({
              message: err.message || "Some error occurred while deleting files."
            });
          });
      })
      .catch(err => {
        res.status(500).send({
          message: err.message || "Some error occurred while retrieving the Kyc."
        });
      });
  };

exports.getKyc = (req, res) => {
const userid = req.params.userid;
console.log(userid);
const condition = {userid:userid}
Kycs.findOne({where:condition})
    .then(async data => {
      console.log(data);
      const str= data.aadhar_front;
      const parts = str.split('/');
      const str1= data.aadhar_back;
      const parts1 = str1.split('/');
      const str2= data.pan;
      const parts2 = str2.split('/');
      const aadharFrontPath = getImageFilePath(parts[3]);
      const aadharBackPath = getImageFilePath(parts1[3]);
      const panPath = getImageFilePath(parts2[3]);
      const aadharFrontBase64 = await getImageAsBase64(aadharFrontPath);
      const aadharBackBase64 = await getImageAsBase64(aadharBackPath);
      const panBase64 = await getImageAsBase64(panPath);

     res.send({
       status:true,
        kycdata: data,
        aadhar_front_base64: aadharFrontBase64,
        aadhar_back_base64: aadharBackBase64,
        pan_base64: panBase64
      });
    })
    .catch(err => {
      res.status(500).send({
        status:false,
        message: "Error retrieving user with id=" + err
      });
    });
};

function getImageAsBase64(imagePath) {
  return new Promise((resolve, reject) => {
    fs.readFile(imagePath, (err, imageData) => {
      if (err) {
        reject(err);
      } else {
        // Convert binary image data to base64
        const base64Image = imageData.toString('base64');
        resolve(base64Image);
      }
    });
  });
}

