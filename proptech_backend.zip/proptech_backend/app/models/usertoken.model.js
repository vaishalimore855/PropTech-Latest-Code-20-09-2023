module.exports = (sequelize, Sequelize) => {
  const User = sequelize.define("user", {
    fullname: {
      type: Sequelize.STRING
    },
    paidAdvertLimit: {
      type: Sequelize.INTEGER,
      defaultValue: 0,
      allowNull: false
    }
  });

  return User;
};
