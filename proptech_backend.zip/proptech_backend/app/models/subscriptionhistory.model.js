module.exports = (sequelize, Sequelize) => {
  const Subscription = sequelize.define("subscription", {
    subscriptionid: {
      type: Sequelize.STRING,
      allowNull: false
    },
    txid: {
      type: Sequelize.STRING,
      allowNull: false
    },
    paymentmethod: {
      type: Sequelize.STRING
    },
    paymentamount: {
      type: Sequelize.STRING
    },
    currency: {
      type: Sequelize.STRING
    },
    status: {
      type: Sequelize.STRING
    }
  });

  return Subscription;
};
