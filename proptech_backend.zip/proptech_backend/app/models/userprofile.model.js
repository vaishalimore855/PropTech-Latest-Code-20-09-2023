module.exports = (sequelize, Sequelize) => {
  const UserProfile = sequelize.define("userprofile", {
    facebookurl: {
      type: Sequelize.STRING
    },
    pinteresturl: {
      type: Sequelize.STRING
    },
    instagramurl: {
      type: Sequelize.STRING
    },
    twitterurl: {
      type: Sequelize.TEXT
    },
    linkedinurl: {
      type: Sequelize.STRING,
    },
    position: {
      type: Sequelize.STRING
    },
    photo: {
      type: Sequelize.STRING
    },
    userid: {
      type: Sequelize.INTEGER
    }
  });

  return UserProfile;
};
