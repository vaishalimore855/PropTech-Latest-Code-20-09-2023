module.exports = (sequelize, Sequelize) => {
  const Mobileverify = sequelize.define("mobileverify", {
    phoneNumber: {
      type: Sequelize.TEXT
    },
    MobileOTP: {
      type: Sequelize.INTEGER,
      defaultValue: 0,
    }
  });

  return Mobileverify;
};
