module.exports = (sequelize, Sequelize) => {
  const AdminRole = sequelize.define("adminrole", {
    role: {
      type: Sequelize.STRING
    },
    status: {
      type: Sequelize.STRING
    },
  
  });


  return AdminRole;
};
