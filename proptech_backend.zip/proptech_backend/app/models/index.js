const dbConfig = require("../config/db.config.js");

const Sequelize = require("sequelize");
const sequelize = new Sequelize(dbConfig.DB, dbConfig.USER, dbConfig.PASSWORD, {
  host: dbConfig.HOST,
  port: dbConfig.PORT,
  dialect: dbConfig.dialect,

  pool: {
    max: dbConfig.pool.max,
    min: dbConfig.pool.min,
    acquire: dbConfig.pool.acquire,
    idle: dbConfig.pool.idle
  }
});

const db = {};

db.Sequelize = Sequelize;
db.sequelize = sequelize;

db.adminroles = require("./adminrole.model.js")(sequelize, Sequelize);
db.adminmenus = require("./adminmenu.model.js")(sequelize, Sequelize);
db.users = require("./user.model.js")(sequelize, Sequelize);
db.kycs = require("./kycdata.model.js")(sequelize, Sequelize);
db.subscriptions = require("./subscription.model.js")(sequelize, Sequelize);
db.subscriptionhistory = require("./subscriptionhistory.model.js")(sequelize, Sequelize);
db.properties = require("./property.model.js")(sequelize, Sequelize);
db.PropertyVerifications = require("./propertyverification.model.js")(sequelize, Sequelize);
db.resettokens = require("./resettoken.model.js")(sequelize, Sequelize);
db.userprofiles = require("./userprofile.model.js")(sequelize, Sequelize);
db.mobileverify = require("./usermobile.model.js")(sequelize, Sequelize);

module.exports = db;
