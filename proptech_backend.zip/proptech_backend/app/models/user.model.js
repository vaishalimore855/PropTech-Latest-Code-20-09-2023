module.exports = (sequelize, Sequelize) => {
  const User = sequelize.define("user", {
    fullname: {
      type: Sequelize.STRING
    },
    email: {
      type: Sequelize.STRING
    },
    password: {
      type: Sequelize.STRING
    },
   role: {
      type: Sequelize.TEXT
    },
   userrole: {
      type: Sequelize.STRING,
    },
    email: {
      type: Sequelize.TEXT,
      allowNull: false
    },
    phoneNumber: {
      type: Sequelize.TEXT
    },
    city: {
      type: Sequelize.STRING
    },
    address: {
      type: Sequelize.STRING
    },
    image: {
      type: Sequelize.STRING
    },
    menu: {
      type: Sequelize.STRING
    },
    isAdmin: {
      type: Sequelize.BOOLEAN,
      defaultValue: false,
      allowNull: false
    },
    // If not verified by admin -> manager can not login
    isVerifiedByAdmin: {
      type: Sequelize.BOOLEAN,
      defaultValue: false,
      allowNull: false
    },
    isBlockedByAdmin: {
      type: Sequelize.BOOLEAN,
      defaultValue: false,
      allowNull: false
    },
    freeAdvertLimit: {
      type: Sequelize.INTEGER,
      defaultValue: 0,
      allowNull: false
    },
    paidAdvertLimit: {
      type: Sequelize.INTEGER,
      defaultValue: 0,
      allowNull: false
    },
    Mobileverified: {
      type: Sequelize.BOOLEAN,
      defaultValue: false,
      allowNull: false
    }
  });

//   const bcrypt = require('bcrypt');

//     sequelize.sync().then(() => {
//   const dataArray = [
//     {
//       fullname: "PropTech Admin",
//       email: "admin@proptech.com",
//       password: "PropTech@123", // Plaintext password
//       role: 1,
//       isAdmin: true
//     },
//   ];

//   // Hash the passwords using bcrypt
//   const saltRounds = 10;
//   dataArray.forEach((user) => {
//     user.password = bcrypt.hashSync(user.password, saltRounds);
//   });

//   // Use bulkCreate with the modified dataArray
//   User.bulkCreate(dataArray)
//     .then(() => {
//       console.log('Data added successfully');
//     })
//     .catch((error) => {
//       console.error('Error adding data:', error);
//     });
// });

  return User;
};
