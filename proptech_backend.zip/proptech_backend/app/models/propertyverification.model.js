module.exports = (sequelize, Sequelize) => {
  const PropertyVerification = sequelize.define("propertyverification", {
    propertyId: {
      type: Sequelize.INTEGER,
      allowNull: false
    },
    surveyNumber: {
      type: Sequelize.STRING,
      allowNull: false
    },
    location: {
      type: Sequelize.STRING,
      allowNull: false
    },
    ownershipHistory: {
      type: Sequelize.TEXT
    },
    transactionHistory: {
      type: Sequelize.TEXT
    },
    liens: {
      type: Sequelize.TEXT
    },
    mortgages: {
      type: Sequelize.TEXT
    },
    charges: {
      type: Sequelize.TEXT
    },
    legalRestrictions: {
      type: Sequelize.TEXT
    },
    images: {
      type: Sequelize.TEXT
    },
    verifystatus: {  
      type: Sequelize.BOOLEAN,
    },
    reason: {
      type: Sequelize.STRING
    }
  });

  return PropertyVerification;
};
