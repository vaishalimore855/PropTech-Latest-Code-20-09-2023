module.exports = (sequelize, Sequelize) => {
  const Adminmenu = sequelize.define("adminmenu", {
    name: {
      type: Sequelize.STRING,
      allowNull: false
    },
    link: {
      type: Sequelize.STRING
    },
    icon: {
      type: Sequelize.STRING
    },
    parentid: {
      type: Sequelize.STRING
    },
    priority: {
      type: Sequelize.TEXT,
      allowNull: false
    },
    type:{
      type: Sequelize.TEXT,
      allowNull: false
    },
    status: {
      type: Sequelize.BOOLEAN,
    },
  });

  return Adminmenu;
};
