module.exports = (sequelize, Sequelize) => {
  const Property = sequelize.define("property", {
    title: {
      type: Sequelize.STRING
    },
    description: {
      type: Sequelize.STRING
    },
    category: {
      type: Sequelize.STRING
    },
    listedIn: {
      type: Sequelize.TEXT,
      allowNull: false
    },
    price: {
      type: Sequelize.TEXT,
      allowNull: false
    },
    yearlyTaxRate: {
      type: Sequelize.STRING
    },
    associationFee: {
      type: Sequelize.STRING
    },
    afterPriceLabel: {
      type: Sequelize.STRING
    },
    beforePriceLabel: {
      type: Sequelize.STRING
    },
    propertyStatus: {
      type: Sequelize.BOOLEAN,
      defaultValue: false,
      allowNull: false
    },
    address: {
      type: Sequelize.STRING
    },
    state: {
      type: Sequelize.STRING
    },
    city: {
      type: Sequelize.STRING
    },
    neighborhood: {
      type: Sequelize.INTEGER,
      defaultValue: 0,
      allowNull: false
    },
    zip: {
      type: Sequelize.INTEGER,
      defaultValue: 0,
      allowNull: false
    },
    latitude: {
      type: Sequelize.FLOAT,
      defaultValue: 0,
      allowNull: false
    },
    longitude: {
      type: Sequelize.FLOAT,
      defaultValue: 0,
      allowNull: false
    },
    sizeInFt: {  
      type: Sequelize.FLOAT,
      defaultValue: 0,
      allowNull: false
    },
    lotSizeInFt: {  
      type: Sequelize.FLOAT,
      defaultValue: 0,
      allowNull: false
    },
    rooms: {
      type: Sequelize.FLOAT,
      defaultValue: 0,
      allowNull: false
    },
    bedrooms: {
      type: Sequelize.FLOAT,
      defaultValue: 0,
      allowNull: false
    },
    bathrooms: {
      type: Sequelize.FLOAT,
      defaultValue: 0,
      allowNull: false
    },
    customID: {
      type: Sequelize.INTEGER, 
      defaultValue: 0,
      allowNull: false
    },
    garages: {
      type: Sequelize.FLOAT,
      defaultValue: 0,
      allowNull: false
    },
    garageSize: {  
      type: Sequelize.FLOAT,
      defaultValue: 0,
      allowNull: false
    },
    yearBuilt: {
      type: Sequelize.INTEGER,  
      defaultValue: 0,
      allowNull: false
    },
    availableFrom: {  
      type: Sequelize.INTEGER,  
      defaultValue: 0,
      allowNull: false
    },
    basement: {
      type: Sequelize.FLOAT,
      defaultValue: 0,
      allowNull: false
    },
    extraDetails: {
      type: Sequelize.TEXT,
      defaultValue: 0,
      allowNull: false
    },
    roofing: {
      type: Sequelize.TEXT,
      defaultValue: 0,
      allowNull: false
    },
    exteriorMaterial: {
      type: Sequelize.TEXT,
      defaultValue: 0,
      allowNull: false
    },
    structureType: { 
      type: Sequelize.TEXT,
      defaultValue: 0,
      allowNull: false
    },
    floorsNo: {
      type: Sequelize.FLOAT,
      defaultValue: 0,
      allowNull: false
    },
    notes: {
      type: Sequelize.TEXT,
      defaultValue: 0,
      allowNull: false
    },
    energyClass: {
      type: Sequelize.TEXT,
      defaultValue: 0,
      allowNull: false
    },
    energyIndex: {
      type: Sequelize.FLOAT,
      defaultValue: 0,
      allowNull: false
    },
    amenities: {
      type: Sequelize.STRING
    },
    images: {
      type: Sequelize.TEXT
    },
    videoid: {
      type: Sequelize.STRING
    },
    videotype: {
      type: Sequelize.STRING
    },
    userid: {  
      type: Sequelize.INTEGER,  
      defaultValue: 0,
      allowNull: false
    },
    agentid: {  
      type: Sequelize.INTEGER,  
      defaultValue: 0
    }
  });

  return Property;
};
