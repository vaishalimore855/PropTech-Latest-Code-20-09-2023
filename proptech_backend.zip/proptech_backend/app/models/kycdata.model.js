module.exports = (sequelize, Sequelize) => {
  const KycData = sequelize.define("kycdata", {
    userid: {
      type: Sequelize.STRING,
      allowNull: false
    },
    aadhar_front: {
      type: Sequelize.STRING
    },
    aadhar_back: {
      type: Sequelize.STRING
    },
   pan: {
      type: Sequelize.TEXT
    }
  });

  return KycData;
};
