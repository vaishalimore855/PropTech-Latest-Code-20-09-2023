module.exports = (sequelize, Sequelize) => {
  const Resettoken = sequelize.define("resettoken", {
    token: {
      type: Sequelize.STRING,
      allowNull: false
    },
    email: {
      type: Sequelize.STRING
    },
    userid: {
      type: Sequelize.STRING
    }
  });

  return Resettoken;
};
