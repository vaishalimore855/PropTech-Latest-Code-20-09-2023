const express = require("express");
const cors = require("cors");
const jwt = require('jsonwebtoken');
const app = express();

var corsOptions = {
  origin: "http://localhost:3000"
};

app.use(cors(corsOptions));

app.use(express.json());

app.use(express.urlencoded({ extended: true }));

const db = require("./app/models");
db.sequelize.sync()
  .then(() => {
    console.log("Synced db.");
  })
  .catch((err) => {
    console.log("Failed to sync db: " + err.message);
  });

//drop the table if it already exists
// db.sequelize.sync({ force: true }).then(() => {
//   console.log("Drop and re-sync db.");
// });

// simple route
app.get("/", (req, res) => {
  res.json({ message: "Welcome to proptech application." });
});

require("./app/routes/admin.routes")(app);
require("./app/routes/adminrole.routes")(app);
require("./app/routes/adminmenu.routes")(app);
require("./app/routes/manager.routes")(app);
require("./app/routes/user.routes")(app);
require("./app/routes/property.routes")(app);
require("./app/routes/propertyverification.routes")(app);
require("./app/routes/subscription.routes")(app);
require("./app/routes/razorpay.routes")(app);
require("./app/routes/users/auth.routes")(app);
require("./app/routes/users/home.routes")(app);
require("./app/routes/subscriptionhistory.routes")(app);
require("./app/routes/users/profile.routes")(app);
require("./app/routes/users/zoom.routes")(app);

const PORT = process.env.PORT || 8090;
app.listen(PORT, () => {
  console.log(`Server is running on port ${PORT}.`);
});



